/**
 *   file: Sorting.java
 */
package c14Package;

import java.util.Vector;

/**
 * 
 * author: Peter Goodmann
 * 
 * Description: This code will be used to sort a list of numbers. It does so by
 * comparing numbers side by side and swapping them if the larger number is on
 * the left or the smaller number is on the right.
 * 
 * 
 *
 */
public class Sorting {

	// the classic bubble sort just for fun
	public static void bubbleSort(int[] list) {
		// check pairs of elements, swapping position until no more swaps are
		// needed

		boolean bSwapped = true;

		while (bSwapped) {
			bSwapped = false;

			// check pairs of items in the entire list
			for (int i = 0; i < list.length - 1; i++)
				if (list[i + 1] < list[i]) {
					int temp = list[i];
					list[i] = list[i + 1];
					list[i + 1] = temp;
					bSwapped = true; // keep sorting!
				}
		}
	}

	// selection sort close to the one described in the Malik book
	// this version sorts the full list, and takes only the list as the
	// parameter
	public static void selectionSort(int[] list) {

		// sort the integer array given using a Selection sort
		int smallestIndex;

		// outer loop:
		// look through every element in the list up the next-to-last item

		for (int index = 0; index < list.length - 1; index++) {
			// find the index (location) of the smallest item in the list

			smallestIndex = index; // before looping through all elements, first
									// item is smallest

			for (int minIndex = index + 1; minIndex < list.length; minIndex++)
				if (list[minIndex] < list[smallestIndex]) // is i'th element
															// smaller?
					smallestIndex = minIndex; // save the location of smaller
												// elements

			
			
			// once the inner for loop is complete, smallestIndex is the
			// location of the
			// first
			// smallest element in the list (if values can repeat)
			if (index != smallestIndex) {
				// swap the values if index is not the smallest
				int temp = list[index];
				list[index] = list[smallestIndex];
				list[smallestIndex] = temp;
			}

		}
	} // end selectionSort

	public static void insertionSort(int[] list) {

		// see chapter 14 for the necessary code to perform an insertion sort
		// include comments
	}
	
	public static void insertionSort1( int[] list ) {

		// see chapter 14 for the necessary code to perform an insertion sort
		int firstOutOfOrder, location; 
		int temp; 
		//process every element in my list
		for (firstOutOfOrder = 1; firstOutOfOrder < list.length; firstOutOfOrder++) 

		if (list[firstOutOfOrder] < list[firstOutOfOrder - 1]) { 
		//element on the left is larger --> find a new spot for it
		temp = list[firstOutOfOrder]; // more efficient swapping
		location = firstOutOfOrder; 
		do {  //shifting elements to the right
		list[location] = list[location - 1]; 
		location--; //decrement location by one 
		} while (location > 0 && list[location - 1] > temp); 
		list[location] = temp;
		}
		}  // end of insertionSort()

	// Chapter 14 Programming Exercise 1 part 1
	// explain the binarySearch algorithm as described on page 918
	// YOU ALSO NEED TO TEST THIS METHOD
	public static int binarySearch(int[] list, int listLength, int searchItem) {

		// type in the code for the binary search found on page 918
		// write the code

		int first = 0;
		int last = listLength - 1;
		int mid;
		boolean found = false;

		while (first <= last && !found) {
			mid = (first + last) / 2; // middle location in the list
			if (list[mid] == searchItem)
				found = true; // we are done if we've found the value
			else if (list[mid] > searchItem)
				last = mid - 1; // next iteration will search lower half
			else
				first = mid + 1; // next iteration will be last half
		}

		// shortcut for if(found) return first; else return -1;
		return found ? first : -1;
	}

	// Chapter 14 Programming Exercise 2
	public static int remove(int[] intArray, int aLength, int removeItem) {
		int i = 0;
		boolean found = false;
		while (!found && i < aLength)
			found = intArray[i++] == removeItem; //compare, increment
		if (found){
			while ( i < aLength)
				intArray[i-1]=intArray[i++];//assign, increment
			return aLength-1;				// done!	
		}
		return aLength;
	}

	// Chapter 14 Programming Exercise 3
	public static int removeAt(int[] intArray, int aLength, int index) {
		while( index<aLength)
			intArray[index++]=intArray[index+1];
		return aLength - 1;
	}

	// Chapter 14 Programming Exercise 4
	public static void removeAll(int[] intArray, int aLength, int removeItem) {

		// delete all occurrences of removeItem from intArray
	}
	
	
	
	
	public static void insertionSort11(int[] list){
		//Sort the int[] list
		//list is modified in-place
		
		int firstOutOfOrder, location;
		int temp;
		
		//process every element in list
		
		for (firstOutOfOrder = 1; firstOutOfOrder < list.length; firstOutOfOrder++)
			if (list[firstOutOfOrder] < list[firstOutOfOrder-1]){
				//element on left is larger, find a new place for this one
				temp = list[firstOutOfOrder];//save for efficient swapping
				location = firstOutOfOrder;
				
				do{ //shift elements to right until items on left are smaller
					list[location] = list[location - 1];
					location--; //decrement by one
				} while (location > 0 && list[location - 1] > temp);
				list[location] = temp;
			}
	//end of insertion sort
	}
	
	
	
	
	

	// Chapter 14 Programming Exercise 9
	public static void insertionSortVector(Vector<String> vString) {

		// add the appropriate Vector type variable to be sorted

		// Vectors are similar to ArrayLists
		//iterate through all items in the vector
		for (int i = 1; i < vString.size(); i++){
			String temp = vString.get(i);
			int j = i - 1;
			//find the correct position for string temp in vString
			while (0 <= j && vString.get(j).compareTo(temp) > 0){
				vString.set(j, vString.get(j - 1));
				j--;
			}
			vString.set(j + 1, temp);
		}

	}

}
